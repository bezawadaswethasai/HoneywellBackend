using Honeywell_POC.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SampleRegistration.BusinessLayer.Interfaces;

namespace Honeywell_POC.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class GoogleMapsController : Controller
  {
    private readonly IRegistrationService _registrationService;
    public GoogleMapsController(IRegistrationService registrationService)
    {
      // _configuration = configuration;
      _registrationService = registrationService;
    }

    [HttpPost]
    [AllowAnonymous]
    [Route("GoogleMaps")]
    public GoogleApiResponse GoogleMap(GoogleApiRequest loginRequest)
    
    {
      var response = new GoogleApiResponse();
      var result = _registrationService.GoogleMap(loginRequest);
      return result;
    }

  }
}
