using Honeywell_POC.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SampleRegistration.BusinessLayer;
using SampleRegistration.BusinessLayer.Interfaces;
using SampleRegistration.Models;
using System.Data.SqlClient;

namespace SampleRegistration.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommonController : ControllerBase
    {
       // private readonly IConfiguration _configuration;
        private readonly IRegistrationService _registrationService;
        public CommonController(IRegistrationService registrationService)
        {
            // _configuration = configuration;
            _registrationService = registrationService;
        }
        [HttpPost]
        [AllowAnonymous]
        [Route("registration")]
        public string Registration(RegistrationRequest model)
        {
            var result= _registrationService.Registration(model);
            return result;

            //MySqlConnection connection = new MySqlConnection(_configuration.GetConnectionString("DbConnection").ToString());
            //MySqlCommand command = new MySqlCommand("INSERT INTO Registration(ID,UserName,Pasword,MobileNo,Email,Address) VALUES('" + model.ID + "','" + model.UserName + "','" + model.Pasword + "','" + model.MobileNo + "','" + model.Email + "','" + model.Address + "')", connection);
            //connection.Open();
            //int i = command.ExecuteNonQuery();
            //if (i > 0)
            //{
            //    return "Data Inserted";
            //}
            //else
            //{
            //    return " Error Occured";
            //}




            return "";

        }

        [HttpPost]
        [AllowAnonymous]
        [Route("login")]
        public LoginResponse Login(LoginRequest loginRequest)
        //public LoginResponse Login([FromQuery] string password, [FromQuery] string username)
        {
            var result = _registrationService.Login(loginRequest.password, loginRequest.username);
            return result;
        }

    }
}
