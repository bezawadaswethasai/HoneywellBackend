﻿namespace SampleRegistration.Models
{
    public class RegistrationResponse
    {
        public int StatusCode {  get; set; }
        public string StatusMessage { get; set; }
    }
}
