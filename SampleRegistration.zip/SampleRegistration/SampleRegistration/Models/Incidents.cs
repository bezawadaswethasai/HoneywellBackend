namespace Honeywell_POC.Models
{
  public class Incidents
  {
    public string Latitude { get; set; }
    public string Longitude { get; set; }
    public bool IsActive { get; set; }
    public string LocationType { get; set; }
    public string ZipCode { get; set; }
  }
}
