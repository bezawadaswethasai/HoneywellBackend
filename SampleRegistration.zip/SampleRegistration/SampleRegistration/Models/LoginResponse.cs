using System.ComponentModel.DataAnnotations;

namespace Honeywell_POC.Models
{
    public class LoginResponse: Error
    {
        [Required]
        public string UserId { get; set; }

        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string Department { get; set; }
        [Required]
        public string Roles { get; set; }
        public DepartmentDetails DepartmentDetails {  get; set; }
    }
}
