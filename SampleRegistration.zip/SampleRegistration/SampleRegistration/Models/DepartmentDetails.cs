using System.ComponentModel.DataAnnotations;

namespace Honeywell_POC.Models
{
  public class DepartmentDetails
  {
    [Required]
    public string region { get; set; }

    [Required]
    public string state { get; set; }
    [Required]
    public string city { get; set; }
    [Required]
    public string country { get; set; }
    [Required]
    public string? zip_code { get; set; }
    [Required]
    public string latitude { get; set; }
    [Required]
    public string longitutude { get; set; }
    [Required]
    public List<int> ZipCodeInDept { get; set; }
  }
}
