﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace SampleRegistration.Models
{
    [ExcludeFromCodeCoverage]
    
    public class RegistrationRequest
    {
        [Required(ErrorMessage = "{0} is a mandatory field")]
        public int ID { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string Pasword { get; set; }
        [Required]
        public string Department { get; set; }
        [Required]
        public string Roles { get; set; }
        [Required]
        public string City {  get; set; }
        [Required]
        public string Region { get; set; }
    }

}
