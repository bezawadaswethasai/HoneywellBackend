using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace Honeywell_POC.Models
{
    public class Error
    {
        
    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string ErrorCode { get; set; }
    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string Message { get; set; }
    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string Data { get; set; }
    }
}
