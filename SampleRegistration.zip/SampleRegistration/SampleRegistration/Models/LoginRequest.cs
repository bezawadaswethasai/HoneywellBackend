using System.ComponentModel.DataAnnotations;

namespace Honeywell_POC.Models
{
  public class LoginRequest
  {
    [Required]
    public string username { get; set; }
    [Required]
    public string password { get; set; }
  }
}
