namespace Honeywell_POC.Models
{
  public class Locations
  {
    public List<Incidents> Incidents { get; set; }
    public List<FireDepartment> FireDepartment {  get; set; }
  }
}
