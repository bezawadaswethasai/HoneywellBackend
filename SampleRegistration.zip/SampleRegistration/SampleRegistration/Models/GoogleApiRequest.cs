namespace Honeywell_POC.Models
{
  public class GoogleApiRequest
  {
    public List<string> Region { get; set; }
    public List<string> ZipCode { get; set; }
    public DateTime FromDate { get; set; }
    public DateTime ToDate { get; set; }
  }
}
