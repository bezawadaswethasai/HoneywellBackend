namespace Honeywell_POC.Models
{
  public class RiskScore
  {
    public string ZipCode { get;set; }
    public string Riskscore { get;set;}
  }
}
