namespace Honeywell_POC.Models
{
  public class GoogleApiResponse
  {
    public Locations locations {  get; set; }
    public List<RiskScore> RiskScore { get; set; }
  }
}
