using SampleRegistration.BusinessLayer;
using SampleRegistration.BusinessLayer.Interfaces;
using SampleRegistration.DataAccessLayer;
using SampleRegistration.DataAccessLayer.Interfaces;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<IRegistrationData, RegistrationData>();
builder.Services.AddScoped<IRegistrationService, RegistrationService>();
builder.Services.AddCors(options =>
{
  options.AddPolicy("AllowOrigin",
      builder => builder.AllowAnyMethod().AllowAnyHeader().SetIsOriginAllowed(origin => true)); // allow any origin.AllowCredentials()
});
//builder.Services.AddCors(options => options.AddPolicy("CorsPolicy",
//     builder =>
//     {
//       builder.AllowAnyMethod().AllowAnyHeader()
//         .WithOrigins("http://localhost:4200/login")
//         .AllowCredentials();
//     }));
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();
app.UseCors("AllowOrigin");
app.UseCors("Cors");

app.Run();
