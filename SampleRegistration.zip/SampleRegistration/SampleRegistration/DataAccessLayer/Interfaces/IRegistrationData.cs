using Honeywell_POC.Models;
using SampleRegistration.Models;

namespace SampleRegistration.DataAccessLayer.Interfaces
{
    public interface IRegistrationData
    {
        string Registration(RegistrationRequest model);
        LoginResponse Login(string password, string Username);
    GoogleApiResponse GoogleMaps(GoogleApiRequest request);
    }
}
