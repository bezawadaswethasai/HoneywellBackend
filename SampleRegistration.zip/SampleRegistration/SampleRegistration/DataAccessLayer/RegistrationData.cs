using MySql.Data.MySqlClient;
using SampleRegistration.DataAccessLayer.Interfaces;
using SampleRegistration.Models;
using System.Data.SqlTypes;
using System.Data;
using Honeywell_POC.Models;
using MySqlX.XDevAPI.Common;

namespace SampleRegistration.DataAccessLayer
{
  public class RegistrationData : IRegistrationData
  {
    private readonly IConfiguration _configuration;

    public RegistrationData(IConfiguration configuration)
    {
      _configuration = configuration;
    }
    public string Registration(RegistrationRequest model)
    {
      MySqlConnection connection = new MySqlConnection(_configuration.GetConnectionString("DbConnection").ToString());
      MySqlCommand command = new MySqlCommand("INSERT INTO Honeywell_FnS_User1(ID,UserName,FirstName,LastName,Pasword,Department,Roles,City,Region) VALUES('" + model.ID + "','" + model.UserName + "','" + model.FirstName + "','" + model.LastName + "',sha1('" + model.Pasword + "'),'" + model.Department + "','" + model.Roles + "','" + model.City + "','" + model.Region + "')", connection);
      connection.Open();
      int i = command.ExecuteNonQuery();
      if (i > 0)
      {
        return "Data Inserted";
      }
      else
      {
        return " Error Occured";

      }
    }

    public LoginResponse Login(string password, string Username)
    {
      var loginResponse = new LoginResponse();
      MySqlConnection connection = new MySqlConnection(_configuration.GetConnectionString("DbConnection").ToString());
      // MySqlCommand command = new MySqlCommand("SELECT Roles,COUNT(*) FROM Honeywell_FnS_User1 where UserName = @Username and Pasword=sha1(@pasword) GROUP BY Roles", connection);
      // MySqlCommand command = new MySqlCommand("SELECT * FROM Users where User_name = @User_name and Password=@password", connection);
      MySqlCommand command2 = new MySqlCommand("SELECT * FROM Users left JOIN FireDepartment_USER_mapping  ON Users.User_id = FireDepartment_USER_mapping.User_ID left JOIN FireDepartment ON FireDepartment_USER_mapping.FireDept_id = FireDepartment.FireDept_ID left JOIN Location ON FireDepartment.location_id = Location.location_id where User_name = @User_name and Password=@password", connection);

      //MySqlCommand command2 = new MySqlCommand("SELECT * FROM Users left JOIN FireDepartment_USER_mapping  ON Users.User_id = FireDepartment_USER_mapping.User_ID left JOIN FireDepartment ON FireDepartment_USER_mapping.FireDept_id = FireDepartment.FireDept_ID left JOIN Location ON FireDepartment.location_id = Location.location_id", connection);
      command2.Parameters.Add("@User_name", MySqlDbType.VarChar).Value = Username;
      command2.Parameters.Add("@password", MySqlDbType.VarChar).Value = password;
      connection.Open();
      int i = command2.ExecuteNonQuery();

      // MySqlDataReader reader1 = command.ExecuteReader();

      MySqlDataReader reader = command2.ExecuteReader();

      // if (reader1.HasRows)
      if (reader.HasRows)
      {


        if (reader.Read())
        {    //Every new row will create a new dictionary that holds the columns

          loginResponse.FirstName = reader["First_name"].ToString();
          loginResponse.LastName = reader["Last_name"].ToString();
          loginResponse.UserId = reader["User_id"].ToString();
          //loginResponse.DepartmentDetails.zip_code= reader["zip_code"].ToString();
          loginResponse.Department = reader["Department"].ToString();
          loginResponse.Roles = reader["Role"].ToString();
          //loginResponse.DepartmentDetails.state = reader["state"].ToString();
          //loginResponse.DepartmentDetails.country = reader["country"].ToString();
          //loginResponse.DepartmentDetails.region = reader["region"].ToString();
          //loginResponse.DepartmentDetails.city = reader["city"].ToString();
          //loginResponse.DepartmentDetails.latitude = reader["latitude"].ToString();
          //loginResponse.DepartmentDetails.longitutude = reader["longitude"].ToString();

          loginResponse.DepartmentDetails = new DepartmentDetails()
          {
            city = reader["city"].ToString(),
          };


        }
        loginResponse.Message = "Login successful";


        return loginResponse;
      }


      else
      {
        var result = new LoginResponse()
        {
          Message = "User Does not exist",
          ErrorCode = "403"

        };
        return result;
      }

    }

    public GoogleApiResponse GoogleMaps(GoogleApiRequest request)
    {
      var response = new GoogleApiResponse();
      MySqlConnection connection = new MySqlConnection(_configuration.GetConnectionString("DbConnection").ToString());
      MySqlCommand command2 = new MySqlCommand("SELECT * FROM Location left JOIN FireDepartment  ON Location.location_id = FireDepartment.location_id left JOIN tbl_FP_BuildingDetails ON Location.location_id = tbl_FP_BuildingDetails.location_id left JOIN tbl_FP_Incident ON tbl_FP_BuildingDetails.building_ID = tbl_FP_Incident.building_ID where Location.Created_On BETWEEN @toDate and @fromDate and Location.region=@region and Location.zip_code=@zipcode", connection);
      command2.Parameters.Add("@toDate", MySqlDbType.VarChar).Value = request.ToDate.ToString("yyyy-MM-dd");
      command2.Parameters.Add("@fromDate", MySqlDbType.VarChar).Value = request.FromDate.ToString("yyyy-MM-dd");
      command2.Parameters.Add("@region", MySqlDbType.VarChar).Value = request.Region;
      command2.Parameters.Add("@zipcode", MySqlDbType.VarChar).Value = request.ZipCode;
      connection.Open();
      int i = command2.ExecuteNonQuery();
      MySqlDataReader reader = command2.ExecuteReader();
      if (reader.HasRows)
      {


        if (reader.Read())
        {
          response.locations = new Locations()
          {
            FireDepartment = new List<FireDepartment>()
             {
               new FireDepartment()
               {
                  Latitude= reader["latitude"].ToString(),
                  Longitude=reader["longitude"].ToString()

               }
             },
            Incidents = new List<Incidents>()
              {
                new Incidents()
                {
                   Latitude=reader["latitude"].ToString(),
                   Longitude=reader["longitude"].ToString()
                }
              }
          };

          return response;
        }
      }


      else
      {
        var result = new LoginResponse()
        {
          Message = "User Does not exist",
          ErrorCode = "403"

        };
        return response;
      }
      return response;
    }

  }
    
}
