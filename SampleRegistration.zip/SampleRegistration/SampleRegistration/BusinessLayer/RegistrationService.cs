using Honeywell_POC.Models;
using SampleRegistration.BusinessLayer.Interfaces;
using SampleRegistration.DataAccessLayer.Interfaces;
using SampleRegistration.Models;
using System.Text;

namespace SampleRegistration.BusinessLayer
{
    public class RegistrationService: IRegistrationService
    {
        private readonly IRegistrationData _registrationData;
        public RegistrationService(IRegistrationData registrationData)
        {
            _registrationData = registrationData;
        }
        public string Registration(RegistrationRequest model)
        {
            //byte[] encData_byte = new byte[model.Pasword.Length];
            //encData_byte = System.Text.Encoding.UTF8.GetBytes(model.Pasword);
            //string encodedData = Convert.ToBase64String(encData_byte);
            //model.Pasword= encodedData;
            var result= _registrationData.Registration(model);
            ////Decode password
            //System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
            //System.Text.Decoder utf8Decode = encoder.GetDecoder();
            //byte[] todecode_byte = Convert.FromBase64String(result.FirstOrDefault().);
            //int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
            //char[] decoded_char = new char[charCount];
            //utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
            //string result = new String(decoded_char);
            return result;
        }
    public GoogleApiResponse GoogleMap(GoogleApiRequest model)
    {
      var result = _registrationData.GoogleMaps(model);
      return result;
    }
      public LoginResponse Login(string password, string Username)
        {
            //byte[] encData_byte = new byte[password.Length];
            //encData_byte = System.Text.Encoding.UTF8.GetBytes(password);
            //string encodedData = Convert.ToBase64String(encData_byte);
            ////return encodedData;
            //var result = _registrationData.Login(encodedData, Username);
            var result = _registrationData.Login(password, Username);
            return result;
        }
    }
}
