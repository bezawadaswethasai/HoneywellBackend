using Honeywell_POC.Models;
using SampleRegistration.Models;

namespace SampleRegistration.BusinessLayer.Interfaces
{
    public interface IRegistrationService
    {
        string Registration(RegistrationRequest model);
        LoginResponse Login(string password, string Username);
    GoogleApiResponse GoogleMap(GoogleApiRequest model);
    }
}
